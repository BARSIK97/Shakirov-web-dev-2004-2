a=input()
f=a.split()
result = '-'.join(f)
print(result)